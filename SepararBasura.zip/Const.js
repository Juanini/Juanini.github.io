// CANASTAS
const SPRITE_CANASTA_COMPOSTA = "textures/01Compostable.png";

// BASURA
const SPRITE_BASURA_SODA = "textures/CristalSoda.png";